package testPlayerv01.Model;

import battlecode.common.*;

public class EnlightenmentCenterInfo
{
    public static Team team;
    public static MapLocation mapLocation;
    public static int currentInfluence; 
    public static int distanceSquaredToEnlightenmentCenter;
    public static int robotId;
}
