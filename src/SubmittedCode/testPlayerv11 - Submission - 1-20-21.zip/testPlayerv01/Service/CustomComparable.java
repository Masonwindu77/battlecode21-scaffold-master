package testPlayerv01.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import battlecode.common.*;
import testPlayerv01.Service.Communication;
import testPlayerv01.Service.EnlightenmentCenterHelper;

public class CustomComparable implements Comparable{

    @Override
    public int compareTo(Object o) {
        // TODO Auto-generated method stub
        return 0;
    }

    
}